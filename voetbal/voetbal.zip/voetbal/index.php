<?php
$conn = mysqli_connect("localhost", "root", "", "voetbal");

$sql = "SELECT * FROM voetballers";
$result = mysqli_query($conn, $sql);

if (!$conn) {
    die("Connect error" . mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="voetbal.css">
    <title>Voetbal</title>
</head>

<body>
    <div class="wrapper">
        <div class="nav">
            <a href="index.php">Home</a>
            <a href="toevoegen.php">Toevoegen</a>
        </div>

        <div class="info">
    <table class="table_info">
        <thead>
            <tr>
                <th>voornaam</th>
                <th>achternaam</th>
                <th>geboortedatum</th>
                <th>aanpassen</th>
                <th>delete</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row["voornaam"]) ?></td>
                        <td><?= htmlspecialchars($row["achternaam"]) ?></td>
                        <td><?= htmlspecialchars($row["geboortedatum"]) ?></td>
                        <td><a href="aanpassen.php?id=<?= urlencode($row['id']) ?>">Aanpassen</a></td>
                        <td><a href="delete.php?id=<?= urlencode($row['id']) ?>">Delete</a></td>
                        </td>
                    </tr>
                </tbody>
        </div>
    <?php endwhile; ?>
<?php endif; ?>


    </div>
</body>

</html>